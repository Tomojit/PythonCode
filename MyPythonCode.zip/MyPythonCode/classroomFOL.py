"""
Author : Tomojit Ghosh
Program Name: classroomFOL.py
Purpose: To implement the class room scheduling by First Order Predicate Logic as part of the assignment 5 of CS440.
Description: In this assignemnt a class "classroomKB" will be written to describe the knowledge base of of class room scheduling. The class "classroomKB" will inherit the class "FolKB" which is taken from the code of Russell & Norvig as a template of the FOL solver. The class contains different predicates to describe the knowledge base. A function "completeSchedule" is also written to check whether a given schedule is complete or not.
"""
from logic import *
from utils import *
classroomKB = FolKB(
	map(expr, ['Class(Cs160)',
		   'Cs160_course(Cs160)',
		   'Cs160_Lab(Cs160A)',
		   'Cs160_Lab(Cs160B)',
		   'Cs160_Lab(Cs160C)',
		   'Cs160_Lab(Cs160D)',
		   'Class(Cs200)',
		   'Cs200_course(Cs200)',
		   'Cs200_Lab(Cs200A)',
		   'Cs200_Lab(Cs200B)',
		   'Class(Cs270)',
		   'Cs270_course(Cs270)',
		   'Cs270_Lab(Cs270A)',
		   'Cs270_Lab(Cs270B)',
		   'ClassRoom(CSB130)',
		   'LabRoom(CSB215)',
		   'LabRoom(CSB225)',
		   'Lab(Cs160A)',
		   'Lab(Cs160B)',
		   'Lab(Cs160C)',
		   'Lab(Cs160D)',
		   'Lab(Cs200A)',
		   'Lab(Cs200B)',
		   'Lab(Cs270B)',
		   'Lab(Cs270A)',		   
		   'SameTime(1,1)',
		   'SameTime(2,2)',
		   'SameTime(3,3)',
		   'SameTime(4,4)',
		   'DifferentTime(1,2)',
		   'DifferentTime(1,3)',
		   'DifferentTime(1,4)',
		   'DifferentTime(2,1)',
		   'DifferentTime(2,3)',
		   'DifferentTime(2,4)',
		   'DifferentTime(3,1)',
		   'DifferentTime(3,2)',
		   'DifferentTime(3,4)',
		   'DifferentTime(4,1)',
		   'DifferentTime(4,2)',
		   'DifferentTime(4,3)',
		   'SameRoom(CSB130)',
		   'SameRoom(CSB215)',
		   'SameRoom(CSB225)',		   
		   'DifferentCourses(Cs160,Cs200)',
		   'DifferentCourses(Cs160,Cs270)',
		   'DifferentCourses(Cs270,Cs200)',
		   'DifferentCourses(Cs200,Cs160)',
		   'DifferentCourses(Cs270,Cs200)',
		   'DifferentCourses(Cs270,Cs160)',
		   #Combination of Cs160A with other labs
		   'DifferentLabs(Cs160A,Cs160B)',
		   'DifferentLabs(Cs160B,Cs160A)',
		   'DifferentLabs(Cs160A,Cs160C)',
		   'DifferentLabs(Cs160C,Cs160A)',
		   'DifferentLabs(Cs160A,Cs160D)',
		   'DifferentLabs(Cs160D,Cs160A)',
		   'DifferentLabs(Cs160A,Cs200A)',
		   'DifferentLabs(Cs200A,Cs160A)',
		   'DifferentLabs(Cs160A,Cs200B)',
		   'DifferentLabs(Cs200B,Cs160A)',
		   'DifferentLabs(Cs160A,Cs270A)',
		   'DifferentLabs(Cs270A,Cs160A)',
		   'DifferentLabs(Cs160A,Cs270B)',
		   'DifferentLabs(Cs270B,Cs160A)',
		   #Combination of Cs160B with other labs
		   'DifferentLabs(Cs160B,Cs160C)',
		   'DifferentLabs(Cs160C,Cs160B)',
		   'DifferentLabs(Cs160B,Cs160D)',
		   'DifferentLabs(Cs160D,Cs160B)',
		   'DifferentLabs(Cs160B,Cs200A)',
		   'DifferentLabs(Cs200A,Cs160B)',
		   'DifferentLabs(Cs160B,Cs200B)',
		   'DifferentLabs(Cs200B,Cs160B)',
		   'DifferentLabs(Cs160B,Cs270A)',
		   'DifferentLabs(Cs270A,Cs160B)',
		   'DifferentLabs(Cs160B,Cs270B)',
		   'DifferentLabs(Cs270B,Cs160B)',
		   #Combination of Cs160C with other labs
		   'DifferentLabs(Cs160C,Cs160D)',
		   'DifferentLabs(Cs160D,Cs160C)',
		   'DifferentLabs(Cs160C,Cs200A)',
		   'DifferentLabs(Cs200A,Cs160C)',
		   'DifferentLabs(Cs160C,Cs200B)',
		   'DifferentLabs(Cs200B,Cs160C)',
		   'DifferentLabs(Cs160C,Cs270A)',
		   'DifferentLabs(Cs270A,Cs160C)',
		   'DifferentLabs(Cs160C,Cs270B)',
		   'DifferentLabs(Cs270B,Cs160C)',
		   #Combination of Cs160D with other labs
		   'DifferentLabs(Cs160D,Cs200A)',
		   'DifferentLabs(Cs200A,Cs160D)',
		   'DifferentLabs(Cs160D,Cs200B)',
		   'DifferentLabs(Cs200B,Cs160D)',
		   'DifferentLabs(Cs160D,Cs270A)',
		   'DifferentLabs(Cs270A,Cs160D)',
		   'DifferentLabs(Cs160D,Cs270B)',
		   'DifferentLabs(Cs270B,Cs160D)',
		   #Combination of Cs200A with other labs
		   'DifferentLabs(Cs200A,Cs200B)',
		   'DifferentLabs(Cs200B,Cs200A)',		   
		   'DifferentLabs(Cs200A,Cs270A)',
		   'DifferentLabs(Cs270A,Cs200A)',
		   'DifferentLabs(Cs200A,Cs270B)',
		   'DifferentLabs(Cs270B,Cs200A)',
		   #Combination of Cs200B with other labs
		   'DifferentLabs(Cs200B,Cs270A)',
		   'DifferentLabs(Cs270A,Cs200B)',
		   'DifferentLabs(Cs200B,Cs270B)',
		   'DifferentLabs(Cs270B,Cs200B)',
		   #Combination of Cs270A with other labs
		   'DifferentLabs(Cs270A,Cs270B)',
		   'DifferentLabs(Cs270B,Cs270A)',
		   #Softconflict time
		   'SoftConflictTime(1,3)',
		   'SoftConflictTime(3,1)',
		   'SoftConflictTime(1,4)',
		   'SoftConflictTime(4,1)',
		   'SoftConflictTime(2,4)',
		   'SoftConflictTime(4,2)',		   		   
		   #Courses must be assigned to a time slot in the room CSB130.
		   '(Scheduled(course,y,z) & Class(course) & LabRoom(y)) ==> Conflict(course,ROOM)',
		   #Lab sections may be assigned to CSB215 or CSB225.
		   '(Scheduled(lab,y,z) & Lab(lab) & ClassRoom(y)) ==> Conflict(lab,ROOM)',
		   #A class cannot meet at two different times.
		   #The first checking is for courses and the second checking is for labs.
		   '(Scheduled(course,y,z) & Scheduled(course,b,c) & Class(course) & DifferentTime(z,c)) ==> Conflict(course,CLASSOVERBOOKED)',
		   '(Scheduled(lab,y,z) & Scheduled(lab,b,c) & Lab(lab) & DifferentTime(z,c)) ==> Conflict(lab,CLASSOVERBOOKED)',
		   #A course cannot meet at the same time as any of its labs.The first checking is for Cs160 course and its labs.
		   #The second checking is for Cs200 course and its labs.The third checking is for Cs270 course and its labs.
		   '(Scheduled(course,y,z) & Scheduled(lab,b,c) & Cs160_course(course) & Cs160_Lab(lab) & SameTime(z,c)) ==> Conflict(course,LABATSAMETIME)',		   
		   '(Scheduled(course,y,z) & Scheduled(lab,b,c) & Cs200_course(course) & Cs200_Lab(lab) & SameTime(z,c)) ==> Conflict(course,LABATSAMETIME)',
		   '(Scheduled(course,y,z) & Scheduled(lab,b,c) & Cs270_course(course) & Cs270_Lab(lab) & SameTime(z,c)) ==> Conflict(course,LABATSAMETIME)',
		   #Courses cs200 and cs270 have the additional requirement that their lab sections must not meet at the same time as either course.The first checking will be done for Cs200 course and Cs270 labs.The second checking will be done for Cs270 course and Cs200 labs.
		   '(Scheduled(course,y,z) & Scheduled(lab,b,c) & Cs200_course(course) & Cs270_Lab(lab) & SameTime(z,c)) ==> Conflict(lab,CS200270)',
		   '(Scheduled(course,y,z) & Scheduled(lab,b,c) & Cs270_course(course) & Cs200_Lab(lab) & SameTime(z,c)) ==> Conflict(lab,CS200270)',
		   #Two courses or labs cannot meet in the same room at the same time.This means two different labs or two different courses  can't meet at the same time in the same room.The first checking will be done on two different courses and the second checking will be done on two different labs.
		   '(Scheduled(course1,room,z) & Scheduled(course2,room,c) & SameRoom(room) & SameTime(z,c) & DifferentCourses(course1,course2)) ==> Conflict(room,ROOMOVERBOOKED)',
		   '(Scheduled(lab1,room,z) & Scheduled(lab2,room,c) & SameRoom(room) & SameTime(z,c) & DifferentLabs(lab1,lab2)) ==> Conflict(room,ROOMOVERBOOKED)',
		   #Encode the soft constraints as rules that conclude SoftConflict(course,lab) so that test_ask('SoftConflict(x,y)',classroomKB) can be added to the test.SOft conflict of each courses and it's associated labs will be determined seperately.
		   '(Scheduled(course,y,z) & Scheduled(lab,b,c) & Cs160_course(course) & Cs160_Lab(lab) & SoftConflictTime(z,c)) ==> SoftConflict(course,lab)',
		   '(Scheduled(course,y,z) & Scheduled(lab,b,c) & Cs200_course(course) & Cs200_Lab(lab) & SoftConflictTime(z,c)) ==> SoftConflict(course,lab)',
		   '(Scheduled(course,y,z) & Scheduled(lab,b,c) & Cs270_course(course) & Cs270_Lab(lab) & SoftConflictTime(z,c)) ==> SoftConflict(course,lab)',
		   #Create a predicate CompleteSched(). When queried (as in "test_ask('CompleteSched()', classroomKB)"), a complete schedule should result in ['{}'] and incomplete should result in [].
		   '(Scheduled(Cs160,y,z) & Scheduled(Cs160A,y1,z1) & Scheduled(Cs160B,y2,z2) & Scheduled(Cs160C,y3,z3) & Scheduled(Cs160D,y4,z4) & Scheduled(Cs200,y5,z5) & Scheduled(Cs200A,y6,z6) & Scheduled(Cs200B,y7,z7) & Scheduled(Cs270,y8,z8) & Scheduled(Cs270A,y9,z9) & Scheduled(Cs270B,y10,z10)) ==> CompleteSched()'
		   
		  ])
)
"""
The following function "completeSchedule" will take the classroom knowledge base to determine whether the KB is is complete or not. Completeless will be determined if all the labs and courses are assigned a schedule. This function will not check the validity of schedules.
Input: Knowledge base - classroomKB
Output: True(if the KB is complete)/False(if the KB is not complete)
"""
def completeSchedule(classroomKB):	
	courses_list=['Cs160','Cs160A','Cs160B','Cs160C','Cs160D','Cs200','Cs200A','Cs200B','Cs270','Cs270A','Cs270B']
	for course in courses_list:		
		for i in range(len(classroomKB.clauses)):			
			if((str(classroomKB.clauses[i])[:9] == "Scheduled") and (str("Scheduled(" + course + ",") in str(classroomKB.clauses[i]))):			
				flag = "False"
				break
				
			else:
				flag = "True"		
		if (flag == "True"):
			return False
	return True

