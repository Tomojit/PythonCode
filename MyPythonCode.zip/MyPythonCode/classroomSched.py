"""
Author : Tomojit Ghosh
Program Name: classroomSched.py
Purpose: To implement the class room scheduling as part of the assignment 4 of CS440
Description: In this assignemnt a class "classroomSched" will be written along with two methods "course_constraints" &
"soft_constraints". These functions are being used to incorporate the constraints as stated in the assignment. This program will use
the code of Russell & Norvig as a template of the CSP problem. In order to incorporate the constraints, the 'nconflict' function of 
CSP class is being over ridden. Also a display function is being added to show the result of the schedule. 
"""

import csp
import utils
courses='cs160 cs161 cs200 cs253 cs270'.split()
lab='cs160A cs160B cs160C cs160D cs161A cs161B cs161C cs161D cs200A cs200B cs253A cs253B cs270A cs270B'.split()
course_lab_map={'cs161': 'cs161A cs161B cs161C cs161D','cs160': 'cs160A cs160B cs160C cs160D','cs200':'cs200A cs200B',
		'cs270':'cs270A cs270B','cs253':'cs253A cs253B'}
def default_soft(A, a, B, b):
    return True

class classroomSched(csp.CSP):
	
	def __init__(self,course_constraints=default_soft,soft_constraints=default_soft):
		course_lab_map={'cs161': 'cs161A cs161B cs161C cs161D','cs160': 'cs160A cs160B cs160C cs160D','cs200':'cs200A cs200B',
		'cs270':'cs270A cs270B','cs253':'cs253A cs253B'}	
		courses='cs160 cs161 cs200 cs253 cs270'.split()
		lab='cs160A cs160B cs160C cs160D cs161A cs161B cs161C cs161D cs200A cs200B cs253A cs253B cs270A cs270B'.split()
		cs_vars = courses + lab
		
		domain = (('CSB130',9),('CSB130',10),('CSB130',11),('CSB130',12),('CSB130',1),('CSB130',2),('CSB130',3),('CSB130',4),
		('CSB215',9),('CSB215',10),('CSB215',11),('CSB215',12),('CSB215',1),('CSB215',2),('CSB215',3),('CSB215',4),
		('CSB225',9),('CSB225',10),('CSB225',11),('CSB225',12),('CSB225',1),('CSB225',2),('CSB225',3),('CSB225',4))
		
		"Building neighbor"
		neighbor_str=''
		for i in cs_vars:
			neighbor_str = neighbor_str+' '+i+':'
			for j in cs_vars:
				if ( i != j ):
					neighbor_str=neighbor_str+' '+j
			if ( i != cs_vars[(len(cs_vars)-1)] ):
				neighbor_str = neighbor_str+';'
		neighbors=csp.parse_neighbors(neighbor_str) 
		csp.CSP.__init__(self, cs_vars, csp.UniversalDict(domain),neighbors, course_constraints,soft_constraints)
		    	
    	" Below function will display the schedule."
    	def display(self, assignment):
		print "# of conflicts in schedule:",len(self.conflicted_vars(self.current)),"\n"
		report={'9_CSB130':'F','10_CSB130':'F','11_CSB130':'F','12_CSB130':'F','1_CSB130':'F','2_CSB130':'F','3_CSB130':'F','4_CSB130':'F',
		'9_CSB215':'F','10_CSB215':'F','11_CSB215':'F','12_CSB215':'F','1_CSB215':'F','2_CSB215':'F','3_CSB215':'F','4_CSB215':'F',
		'9_CSB225':'F','10_CSB225':'F','11_CSB225':'F','12_CSB225':'F','1_CSB225':'F','2_CSB225':'F','3_CSB225':'F','4_CSB225':'F',}
		key=assignment.keys()
		for i in key:
			value=assignment[i]
			if(report[str(value[1])+"_"+str(value[0])] == 'F'):
				report[str(value[1])+"_"+str(value[0])] = i
		timeslot=['9','10','11','12','1','2','3','4']
		rooms=['CSB130','CSB215','CSB225']
		content='       CSB130   CSB215  CSB225'+ '\n' + '----------------------------------' + '\n'
		for t in timeslot:
			if (t == '1' or t == '2' or t == '3' or t == '4' or t == '9'):
				content=content+' '+t+' |'
			else:
				content=content+t+' |'
			for r in rooms:
				if(report[str(t+"_"+r)] != 'F'):
					#content=content+'    ' + report[str(t+"_"+r)]
					content=content+'\t' + report[str(t+"_"+r)]
				else:
					#content=content+'         '	
					content=content+'\t'	
			content=content+'\n'	
		print content		
		
	"This is the orverridden nconflicts to incorporate the soft-constraints"
	def nconflicts(self, var, val, assignment):
		"Return the number of conflicts var=val has with other variables."
		# Subclasses may implement this more efficiently
		#print "I'm in my own nconflicts",'\n'
		def conflict_hrd(var2):
			val2 = assignment.get(var2, None)
			return val2 != None and not self.constraints(var, val, var2, val2)
		def conflict_soft(var2):
			val2 = assignment.get(var2, None)
			return val2 != None and not self.soft(var, val, var2, val2)
		hrd_cnt = utils.count_if(conflict_hrd, self.neighbors[var])
		soft_cnt = utils.count_if(conflict_soft, self.neighbors[var])
		#print "soft_cnt=",soft_cnt
		return (2*hrd_cnt + soft_cnt)
	
" Below function will detect the hard constraint."
def course_constraints(A, a, B, b):	
	"Two courses or labs cannot meet in the same room at the same time, note this is a double variable constraint."
	if(a == b):	
		#print "Print1"	
		return False
	"A course cannot meet at the same time as any of its labs, note this is a double variable constraint."
	if((A in courses and B in lab) and (B in course_lab_map[A]) and (a[1]==b[1])):		
		#print "Print2"
		return False
	if((B in courses and A in lab) and (A in course_lab_map[B]) and (b[1]==a[1])):		
		#print "Print3"
		return False
	"""Courses cs200 and cs270 havethe additional requirement that they cannot meet at the same time and their lab
	sections must not meet at the same time as either course, note this is a double variable constraint.."""	
	if(((A == 'cs200' and B in course_lab_map['cs270']) and (a[1]==b[1])) or ((A == 'cs270' and B in course_lab_map['cs200']) and (a[1]==b[1]))):
		#print "Print4"
		return False
	"A course must be scheduled in CSB130, note this is a single variable constraint."
	#if((A in courses and a[0] != 'CSB130') or (B in courses and b[0] != 'CSB130')):
	if(A in courses and a[0] != 'CSB130'):
		#print "Print5"
		return False
	"a lab section can be scheduled in either room, note this is a single variable constraint."
	if(A in lab and a[0] == 'CSB130'):
		#print "Print6"
		return False	
	#print "Print7"
	return True	

" Below function will detect the soft constraint."
def soft_constraints(A, a, B, b):
	"""A lab section should be held in a time slot adjacent to the course (e.g., if cs200 is at
	noon, its two labs should be held at 11 or 1)"""	
	
	if((A in lab and B in courses) and (A in course_lab_map[B])):
		if((abs(a[1] - b[1]) == 1) or ((a[1] == 12 and b[1] == 1) or (b[1] == 12 and a[1] == 1))):
			return True
		else:
			return False
	else:		
		return True

if __name__ == '__main__':
	cs1 = classroomSched(course_constraints)		
	csp.min_conflicts(cs1,10)
	#print "Solution for cs1=",cs1.current,"\n"
	cs1.display(cs1.current)
	print
	cs2 = classroomSched(course_constraints, soft_constraints)
	csp.min_conflicts(cs2,10)
	#print "Solution for  cs2=",cs2.current,"\n"	
	cs2.display(cs2.current)
	
