#! /usr/bin/env python
"""
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++				
				Programmer Name: Tomojit Ghosh
				  Colorado State University

Purpose: The purpose of this code is to implement the A* Algorithm as described in the book "Artificial Intelligence
-A Modern Approach(3rd Edition") by Stuart Russel & Peter Norvig - Chapter3 (Solving Problems by Searching), section 
3.5 Informed (Heuristic) Search Strategies.
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
support code for the rush-hour game
ASSUMPTIONS
 1. game file is formatted correctly
 2. goal is always in the 3rd row
 3. empty positions are indicated by '0'

INITIALIZATION
  LOAD-GAME:  Load a game from a file, and create a game instance
  to record all of the information.  
"""

def load_game(filename):
    """Reads filename and returns a list representing the initial state of the game"""
    fin = open(filename)
    nextline = fin.readline()
    maxX, maxY = [int(token) for token in nextline.split()]
    gameArray = []
    for i in range(maxX):
        nextline = fin.readline()
        gameArray.append(nextline.split())
    fin.close()
    return gameArray

# UTILITIES
# PRINT_BOARD: nicely formats a game board
def print_board(board):
    """pretty print the board"""
    for i in board:
        for j in i:
            print j.rjust(4),
        print

# COPY_GAME: lists are mutable in python. sometimes a full copy is needed of a board
def copy_game(alist):
    """alist should be a 2D matrix representing a game state. returns a copy of the game state"""
    newlist = []
    for row in range(len(alist)):
        newlist = newlist + [list(alist[row])]
    return newlist

# EQUAL_GAMES: returns True if two game boards have the same values at all the positions
def equal_games(game1, game2):
    """games are board states, returns True if two game boards have the same values at all the positions"""
    # do they have the same number of rows?
    if len(game1) == len(game2):
        for i in range(len(game1)):
            # do they have the same number of columns?
            if len(game1[i]) == len(game2[i]):
                for j in range(len(game1[i])):
                    # as soon as a position has a different value, they are not equal
                    if game1[i][j] != game2[i][j]:
                        return False
        return True
    else:
        return False

# LEGAL_POSITION: returns True if x y position on the board exists
def legal_position(board, x, y):
    """returns True if (x, y) is on the board"""
    return x >= 0 and y >= 0 and x < len(board) and y < len(board[0])

# EMPTY: check to see if an x y position on the board exists and is empty
#        returns True or False
def empty(board, x, y):
    """returns True if the (x, y) position on the board is empty"""
    if legal_position(board, x, y):
        if board[x][y] == '0':
            return True
    return False

# AT_GOAL: checks whether a board is actually at the goal state
#          i.e., g is at the rightmost column
def at_goal(board):
    """returns True if goal is in the rightmost column"""
    return board[2][len(board[2]) - 1] == 'g'

# list_valid_move: returns all poosible moves applicable on a board state.
def list_valid_move(board):
    col=len(board[0])
    row=len(board)
    #print "row#",row,"col#",col,"\n"
    moves=[]
    for i in range(row):
        for j in range(col):
            #print i,",",j,"\n"
            if(not(empty(board, i, j))):
                #print i,",",j,"\n"
                if(('g' in board[i][j]) or ('c' in board[i][j])):
                    v_len=2
                    #print v_len ,"\n"
                    #print i,",",j,"\n"
                else:
                    v_len=3
		if(legal_position(board, i, j-1) and empty(board, i, j-1) and legal_position(board, i, j+1)):
                    #print i,",",j,"i, j+1 block","\n"
                    if((board[i][j] == board[i][j+1]) and v_len == 2):
                        #print i,",",j,"\n"
		        moves.append([[i,j+1],3])
                    if((board[i][j] == board[i][j+1]) and v_len == 3): #for truck move
                        moves.append([[i,j+2],3])
                if(legal_position(board, i, j+1) and empty(board, i, j+1) and legal_position(board, i, j-1)):
                    #print i,",",j,"i, j-1 block","\n"
                    if((board[i][j-1] == board[i][j]) and v_len == 2):
		        #print i,",",j,"\n"
                        moves.append([[i,j-1],1])
                    if((board[i][j-1] == board[i][j]) and v_len == 3): #for truck move
                        moves.append([[i,j-2],1])
		if (legal_position(board, i+1, j) and empty(board, i+1, j) and legal_position(board, i-1, j)):
                    if((board[i][j] == board[i-1][j]) and v_len == 2):
                        #print i,",",j,"\n"
		        moves.append([[i-1,j],2])
                    if((board[i][j] == board[i-1][j]) and v_len == 3):#for truck move
                         moves.append([[i-2,j],2])
                if(legal_position(board, i-1, j) and empty(board, i-1, j) and legal_position(board, i+1, j)):
                    if((board[i][j] == board[i+1][j]) and v_len == 2):
                        #print i,",",j,"\n"
		        moves.append([[i+1,j],0])
                    if((board[i][j] == board[i+1][j]) and v_len == 3): #for truck move
                        moves.append([[i+2,j],0])
                #else:
                    #print "Position [",i,",",j,"]"," is not valid for any move."
    return moves

#move_up: This function will move any board element one position up.
def move_up(x,y):    
    tmp_board= board_ins
    row=len(tmp_board[0])
    col=len(tmp_board)
    v_len=0    
    obj= tmp_board[x][y]
    if('g' in tmp_board[x][y]):
        v_len=2                
    elif('c' in tmp_board[x][y]):
        v_len=2        
    else:
        v_len=3        
    for i in range(row):
        for j in range(col):
            if((i==x) and j==y):
                board_ins[i][j] = '0'
                board_ins[i-v_len][j] = obj
    #print_board(board_ins)

#move_down: This function will move any board element one position down.
def move_down(x,y):
    tmp_board= board_ins
    row=len(tmp_board[0])
    col=len(tmp_board)
    v_len=0    
    obj= tmp_board[x][y]
    if('g' in tmp_board[x][y]):
        v_len=2                
    elif('c' in tmp_board[x][y]):
        v_len=2        
    else:
        v_len=3        
    for i in range(row):
        for j in range(col):
            if((i==x) and j==y):
                board_ins[i][j] = '0'
                board_ins[i+v_len][j] = obj
    #print_board(board_ins)

#move_right: This function will move any board element one position right.
def move_right(x,y):    
    tmp_board= board_ins
    row=len(tmp_board[0])
    col=len(tmp_board)    
    tupl = ()
    obj= tmp_board[x][y]
    if('g' in tmp_board[x][y]):
        v_len=2                
    elif('c' in tmp_board[x][y]):
        v_len=2        
    else:
        v_len=3        
    for i in range(row):
        for j in range(col):
            if((i==x) and j==y):
                board_ins[i][j] = '0'
                board_ins[i][j+v_len] = obj                
    #print_board(board_ins)

#move_left: This function will move any board element one position left.
def move_left(x,y):    
    tmp_board= board_ins
    row=len(tmp_board[0])
    col=len(tmp_board)
    v_len=0    
    obj= tmp_board[x][y]
    if('g' in tmp_board[x][y]):
        v_len=2              
    elif('c' in tmp_board[x][y]):
        v_len=2        
    else:
        v_len=3        
    for i in range(row):
        for j in range(col):
            if((i == x) and (j==y)):
                board_ins[i][j] = '0'                
                board_ins[i][j-v_len] = obj
    #print_board(board_ins)

#inadmissible: This function will return a admissible heuristic value calculated on board state.     
def inadmissible(board):
	
	col_no=len(board[2])	
	row_no=len(board)
	h=0
	no_of_truck=0
	no_of_car=0
	goal_position=0
	no_of_obstacle=0
	if(at_goal(board)):
		return 0	
	for i in range (col_no):
		if(board[2][i] == 'g' and goal_position ==0 ):
			goal_position =i	
		if(goal_position != 0 and board[2][i] != 'g' and board[2][i] != '0'):
			no_of_obstacle= no_of_obstacle + 1
	dist_frm_g = col_no - (goal_position+1)
	for i in range (col_no):
		if(board[2][i] == 'g' and goal_position ==1000 ):
			goal_position =i
		if(goal_position != 1000 and board[2][i] != 'g' and board[2][i] != '0' and board[2][i] != 't'):
			no_of_truck= no_of_truck + 1
		if(goal_position != 1000 and board[2][i] != 'g' and board[2][i] != '0' and board[2][i] != 'c'):
			no_of_car= no_of_car + 1
	#h= col_no -2 - goal_position
	h= col_no -2 - goal_position + no_of_car*1 + no_of_truck*1
	return h
	
	
#admissible: This function will return a inadmissible heuristic value calculated on board state.
def admissible(board):
	"""
This is my Admissible heurictic. I know the following info. about the rush hour
	1. Goal vehicle will always be on teh 3rd row.
	2. The board will be at a goal state if the goal vehicle reached at the right most edge/column.
	3. There can't be any vehicle, which can move horizontally on the 3rd row, before the goal.
	4. There can be vehicle, which can move vertically thur a column, before the goalvehicle.
	5. The length of goal vehicle is 2.
	6. The length of a car is 2. I assume a car will be denoted by the letter 'c' but it can have a digit as suffix.
	7. The length of a truck is 3. I assume a car will be denoted by the letter 't' but it can have a digit as suffix.
To implement the admissible heuristic I will calculate the straight path distance of the goal vehicle to reach the right most column.
If there is no obstacle then the distance will be the number of moves of the goal vehicle to reach goal column.For any additional obstacle I will add 2 moves for a car and 3 moves for a truck. I'm also considering the number of moves available to reach to goal.
	"""
	col_no=len(board[2])
	row_no=len(board)
	toys_no=0
	h=0
	goal_position=1000
	no_of_truck=0
	no_of_car=0
	board_density=0.0
	valid_moves=[]
	valid_moves=list_valid_move(board)
	valid_moves.sort()
	valid_moves.reverse()
	for j in range(row_no):
		for i in range (col_no):
			if(board[j][i] != '0'):
				toys_no=toys_no+1
			if(j==2):
				if(board[j][i] == 'g' and goal_position == 1000 ):
					goal_position =i					
				if((i > goal_position) and ('t' in board[j][i])):					
					no_of_truck= no_of_truck + 1
				if((i > goal_position) and ('c' in board[j][i])):
					no_of_car= no_of_car + 1
	#print "Total no. of toys=",toys_no
	h= col_no -2 - goal_position + no_of_car*2 + no_of_truck*3		
	#print "Heuristic=",h,"\n"		
	#print valid_moves
	
	for move in valid_moves:
		mov_elm = board[move[0][0]][move[0][1]]
		if((move[0][0]==2) and ((move[1]==1) or (move[1]==2))):
			h=h-1
				
	#sys.exit()
	return h

#a_star_search: This function will return a solution path if found. Other wise it will return failure.
#Function is using admissible and inadmissible heuristic calculation to perform the search

def a_star_search(board, h_function):
	from copy import deepcopy
    	import sys
    	import re
    	import Queue
    	global board_ins
	h=0
	board_ins = board    
    	valid_moves=[]
    	#valid_moves=list_valid_move(board_ins)
    	#print valid_moves
    	explored=[]
	parent_child={}
	frontier_cost={}
	explored_cost={}
	depth_limit={}
	parent_child[str(board_ins)] = 'IS'
    	frontier=Queue.PriorityQueue()
	#print "Type of frontier",type(frontier)
	h=0
	h=h_function(board_ins)
	depth_limit[str(board_ins)] = 0
	#f_n[str(board_ins)] = h
	#print "Heuristic of IS:",h,"\n"
    	path_search=[]
	#print "Printing board ins...",board_ins
	frontier.put((h, board_ins))
    	goal_reached="n"
    	search_path={}
    	first_time='Y'
	#node=deepcopy(frontier.get())
	node=frontier.get()
	#print "printing node...",node
	if((at_goal(node[1])) and first_time=='Y'):#If IS is in goal state
		#explored.append(node[1])
            	#print "Initial state = Goal state. No need to search...\n"
	    	#print "No of explored nodes=",explored
		path=()
		path=(['exit'],0,0)
		return path
            	#sys.exit()
	valid_moves=list_valid_move(node[1])
	valid_moves.sort()
	valid_moves.reverse() 	
    	#print "Printing moves for IS...",valid_moves,"\n"             
    	explored.append(node[1])
	explored_cost[str(node[1])] = str(node[0])
    	#print "Printing explored...",explored,"\n"  
	#sys.exit()      
    	for move in valid_moves:
        	#board_ins=deepcopy(node)
        	board_ins=deepcopy(node[1])
        	#print "Applying move:",move,"on \n",print_board(board_ins)
        	if(move[1]==0):                    
            		move_up(move[0][0],move[0][1])
            		#print_board(board_ins)
        	elif(move[1]==1):                    
            		move_right(move[0][0],move[0][1])
            		#print_board(board_ins)
        	elif(move[1]==2):                    
            		move_down(move[0][0],move[0][1])  
            		#print_board(board_ins)
        	else:                
            		move_left(move[0][0],move[0][1])
            	#print_board(board_ins)
            	#print "Printing Node...\n"
        	#print "Printing current board...\n", print_board(board_ins)
		h=0
		h=h_function(board_ins)
		#print "Printing heuristic for board ",board_ins,"\n",h
        	search_path[str(board_ins)] = 'IS' + ';' + str(move)
		frontier.put((h+1, board_ins))
		frontier_cost[str(board_ins)] = h+1
		parent_child[str(board_ins)] = str(node[1])
		depth_limit[str(board_ins)] = 1
		#print "parent_child=",str(parent_child)
        	#print "Printing frontier from IS...",frontier
		#sys.exit()
	#print "depth_limit before while loop=\n",str(depth_limit),"\n"
        while(frontier.queue):
		#print"Len of Frontier: ",len(str(frontier.queue))
		#sys.exit()      
        	node=deepcopy(frontier.get())
		#print "Node inside while loop:",node[1]
		cur_node_dlim = depth_limit.get(str(node[1]))
		#print "cur_node_dlim=",cur_node_dlim,"\n"        
        	if(at_goal(node[1])):                    
            		path=list()
			path_len=0
            		tmp_state = str(node[1])
            		#print str(search_path), "\n"
            		#sys.exit()
            		while(tmp_state != 'IS'):
                		#print "Inside While for path search \n"
                		result = search_path.get(tmp_state)
                		#print "\n Hash entry:", result,"\n"
                		state,tmp_path = re.split(';',result)
                		#print "state: ",state,"\n"
                		#path=path + tmp_path
				#print "tmp_path=",tmp_path
                		path.append(tmp_path)
                		#print "Path: ",path,"\n"
                		tmp_state = state
                		#print "tmp_state:", tmp_state,"\n"
            		goal_reached="y"
            		#print "reached goal \n"
			#print path
			#sys.exit()
            		path.reverse()
			path_len = len(path)
            		path.append(['exit'])
			path.append(path_len)            		
            		path.append(len(explored))
            		#print "Path:",path,"\n"
			#print_board(node[1])
			#path=tuple(path)
			return tuple(path) 
	    		#break
        	explored.append(node[1])
		explored_cost[str(node[1])] = str(node[0])        
        	valid_moves=list_valid_move(node[1])
		valid_moves.sort()
		valid_moves.reverse()    	
        	#print "Printing moves...",valid_moves,"\n"        
        	#print "Printing explored...",explored,"\n"        
        	#print "Printing valid moves for node:\n",print_board(node),valid_moves
        	for move in valid_moves:
            		#board_ins=deepcopy(node)
            		board_ins=deepcopy(node[1])
            		#print "Applying move:",move,"on \n",print_board(board_ins)
            		if(move[1]==0):                    
                		move_up(move[0][0],move[0][1])
                		#print_board(board_ins)
            		elif(move[1]==1):                    
                		move_right(move[0][0],move[0][1])
                		#print_board(board_ins)
            		elif(move[1]==2):                    
                		move_down(move[0][0],move[0][1])  
                		#print_board(board_ins)
            		else:                
                		move_left(move[0][0],move[0][1])
               			#print_board(board_ins)
                		#print "Printing Node...\n"
			h=0
			h=h_function(board_ins)
			#print "printing parent child",str(parent_child), "\n"
			#calculating the cost of the current node. I've h(n), I'll calculate the g(n) and then will add to figure out f(n)						
			if( (str(board_ins) not in str(explored)) and (str(board_ins) not in str(frontier.queue)) ):
				#print "Tomojit"
				#print "h=",h,"\n"
				#print "cur_node_dlim in if statement=",cur_node_dlim,"\n"
				#h1=h + cur_node_dlim + 1
				#frontier.put((h1, board_ins))
				g_n= cur_node_dlim + 1

			if(str(board_ins) in str(parent_child)):
				g_n= cur_node_dlim + 1
				#print "Ghosh"
			# Now I'll calculate f(n) and make the decision if I need to update/insert frontier/explored
			f_n= g_n + h			
			# Putting the new node into the frontier
			if( (str(board_ins) not in str(explored)) and (str(board_ins) not in str(frontier.queue)) ):
				frontier.put((f_n, board_ins))
				search_path[str(board_ins)] = str(node[1]) + ';' + str(move)
				parent_child[str(board_ins)] = str(node[1])
				depth_limit[str(board_ins)] = cur_node_dlim + 1
				#print "Tomojit Ghosh"
			#Now I'll check if the node is in frontier alreday and if it's current cost is lower than the existing cost
			#then I'll update frontier. 
			if( str(board_ins) in str(frontier.queue) ):
				temp_list=[]
				#print "Assignment 3"
				while(frontier.queue):
					elm=frontier.get()
					#print "printing elm:",elm
					temp_list.append(elm)
					if(str(board_ins) == str(elm[1])):						
						break
				for i in temp_list:
					if( (str(i[1]) == str(board_ins) ) and (i[0] > f_n)):
						frontier.put((f_n, i[1]))
					else:
						frontier.put((i[0], i[1]))
			#Now I'll check if the node is in explored and if it's current cost is lower than the existing cost
			#then I'll put the node back in frontier.
			if( str(board_ins) in str(explored) ):
				tmp_f_n = frontier_cost.get(str(board_ins))
				if(tmp_f_n > f_n):
					frontier.put((f_n, board_ins))
					explored.pop(explored.index(board_ins))
					del frontier_cost[str(board_ins)]
			#print "g_n=",g_n,"for board ins \n",print_board(board_ins)

#I'm checking here if the frontier is exhausted completely and no goal state is reached
	if(goal_reached != 'y' and (frontier.empty())):
		path=()
		path=(['fail'],0,len(explored))
		return path
		
## SEARCH CODE
# Top Level function is RushHour which takes a game file and a string indicating whether to use dfs or bfs
def RushHour(filein, algo, hType):	
	game = load_game(filein)
	if(algo=='astar'):
        	solution=a_star_search(game, hType)
		#print solution        

#if __name__ == '__main__' :
import sys
RushHour('grade_easy.text', 'astar',admissible)

