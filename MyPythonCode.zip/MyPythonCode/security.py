"""
Author : Tomojit Ghosh
Program Name: security.py
Purpose: To implement the Bayesian Network using Russell and Norvig's Python code for Bayesian Networks as part of the assignment 6 of CS440.
Description: In this assignemnt a class "Security" will be written to represent the DOS exploit in a Bayesian Network probability diestribution model. The description of the DOS exploit is givne in the paper as part of assignment 6. The class "BayesNet" will inherit the class "BayesNet" which is taken from the code of Russell & Norvig as a template of the Bayesian Network probability solver. The functions  "elimination_ask","enumeration_ask" and "show_approx" will be used to display the result of any query.
"""
from logic import *
from utils import *
from probability import *
Security = BayesNet([
    ('SunJRE14002', '', 0.5),
    ('AdobeReader941', '', 0.5),
    ('AdobeFlash60880', '', 0.5),
    ('UserBrowsing', '', 0.922),
    ('UsesSocialNet', '', 0.015),
    ('JDKJRECVE20083111', 'SunJRE14002',{T: 0.99968, F: 0}),
    ('MemCorruptCVE20104091', 'AdobeReader941',{T: 0.85888, F: 0}),
    ('JavaCPUJuly2009', 'SunJRE14002',{T: 0.99968, F: 0}),
    ('AdobeFlashCVE20100187', 'AdobeFlash60880',{T: 0.85888, F: 0}),
    ('CraftedPDF', '', 0.28),
    ('StartsJWS', 'UserBrowsing',{T: 0.929, F: 0}),
    ('LoadsPDF', 'UserBrowsing',{T: 0.015, F: 0}),
    ('ModSWFinFriend', '', 0.43),
    ('UsesLDAP', '', 0.015),
    ('AppwLongValue', '', 0.28),
    ('OpensFlash', 'UsesSocialNet',{T: 0.914, F: 0}),
    ('CVE20083111Exploited', 'JDKJRECVE20083111 AppwLongValue StartsJWS',{(T,T,T): 0.999, (T,T,F): 0,(T,F,T): 0,(T,F,F): 0,(F,T,T): 0,
    (F,T,F): 0,(F,F,T): 0,(F,F,F): 0}),
    ('CVE20104091Exploited', 'MemCorruptCVE20104091 CraftedPDF LoadsPDF',{(T,T,T): 0.93, (T,T,F): 0,(T,F,T): 0,(T,F,F): 0,(F,T,T): 0,
    (F,T,F): 0,(F,F,T): 0,(F,F,F): 0}),
    ('CVE20100187Exploited', 'AdobeFlashCVE20100187 ModSWFinFriend OpensFlash',{(T,T,T): 0.43, (T,T,F): 0,(T,F,T): 0,(T,F,F): 0,(F,T,T): 0,
    (F,T,F): 0,(F,F,T): 0,(F,F,F): 0}),
    ('CVE20091094Exploited', 'JavaCPUJuly2009 UsesLDAP',{(T,T): 0.999, (T,F): 0,(F,T): 0,(F,F): 0}),
    ('DOS', 'CVE20100187Exploited CVE20083111Exploited CVE20091094Exploited CVE20104091Exploited',{(T,T,T,T): 0.95, (T,T,T,F): 0.95,
    (T,T,F,T):0.95,(T,T,F,F): 0.95,(T,F,T,T): 0.95,(T,F,T,F): 0.95,(T,F,F,T): 0.95,(T,F,F,F): 0.95,(F,T,T,T): 0.95,(F,T,T,F): 0.95,
    (F,T,F,T): 0.95,(F,T,F,F): 0.95,(F,F,T,T): 0.95,(F,F,T,F): 0.95,(F,F,F,T): 0.95,(F,F,F,F): 0.0})
    ])

